self.addEventListener("fetch", function(e) {}); /* not actually caching anything. just a dummy service worker so we can install. */
